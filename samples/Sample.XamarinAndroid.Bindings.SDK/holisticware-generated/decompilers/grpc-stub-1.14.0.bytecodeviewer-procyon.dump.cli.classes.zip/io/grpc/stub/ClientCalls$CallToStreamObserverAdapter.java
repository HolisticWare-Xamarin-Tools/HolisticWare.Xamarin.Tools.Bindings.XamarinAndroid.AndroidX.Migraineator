package io.grpc.protobuf.lite;

import io.grpc.*;
import com.google.protobuf.*;

private static final class MetadataMarshaller<T extends MessageLite> implements Metadata.BinaryMarshaller<T>
{
    private final T defaultInstance;
    
    MetadataMarshaller(final T defaultInstance) {
        this.defaultInstance = defaultInstance;
    }
    
    public byte[] toBytes(final T value) {
        return value.toByteArray();
    }
    
    public T parseBytes(final byte[] serialized) {
        try {
            return (T)this.defaultInstance.getParserForType().parseFrom(serialized, ProtoLiteUtils.globalRegistry);
        }
        catch (InvalidProtocolBufferException ipbe) {
            throw new IllegalArgumentException((Throwable)ipbe);
        }
    }
}
