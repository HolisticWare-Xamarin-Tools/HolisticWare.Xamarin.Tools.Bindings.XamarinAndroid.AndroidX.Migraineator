/*
 * Decompiled with CFR 0_125.
 * 
 * Could not load the following classes:
 *  com.google.errorprone.annotations.DoNotMock
 *  io.grpc.ExperimentalApi
 *  io.grpc.stub.CallStreamObserver
 */
package io.grpc.stub;

import com.google.errorprone.annotations.DoNotMock;
import io.grpc.ExperimentalApi;
import io.grpc.stub.CallStreamObserver;

@DoNotMock
@ExperimentalApi(value="https://github.com/grpc/grpc-java/issues/1788")
public abstract class ServerCallStreamObserver<V>
extends CallStreamObserver<V> {
    public abstract boolean isCancelled();

    public abstract void setOnCancelHandler(Runnable var1);

    public abstract void setCompression(String var1);
}

